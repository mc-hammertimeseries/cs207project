```
py35)➜  cs207project git:(part3) ✗ ./both.sh
Generating LALR tables
S> Starting TSDB server on port 9999
Generating LALR tables
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-31', 'md': {'order': -2, 'blarg': 2, 'vp': True}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-23', 'md': {'order': 0, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-33', 'md': {'order': 0, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-34', 'md': {'order': -2, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-15', 'md': {'order': -5, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-10', 'md': {'order': -5, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-24', 'md': {'order': 3, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-36', 'md': {'order': 3, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-35', 'md': {'order': 1, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-2', 'md': {'order': -3, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-21', 'md': {'order': -4, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-48', 'md': {'order': 3, 'blarg': 1, 'vp': True}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-17', 'md': {'order': -2, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-8', 'md': {'order': -2, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-39', 'md': {'order': 1, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-29', 'md': {'order': -5, 'blarg': 2, 'vp': True}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-25', 'md': {'order': 3, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-19', 'md': {'order': 3, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-16', 'md': {'order': 2, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-41', 'md': {'order': -4, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-32', 'md': {'order': -3, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-5', 'md': {'order': -1, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-49', 'md': {'order': -3, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-4', 'md': {'order': -5, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-30', 'md': {'order': -5, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-40', 'md': {'order': 5, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-6', 'md': {'order': -1, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-7', 'md': {'order': -1, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-43', 'md': {'order': 3, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-0', 'md': {'order': -2, 'blarg': 1, 'vp': True}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-12', 'md': {'order': -5, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-38', 'md': {'order': -1, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-37', 'md': {'order': 3, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-42', 'md': {'order': -2, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-45', 'md': {'order': 2, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-46', 'md': {'order': 3, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-18', 'md': {'order': -4, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-27', 'md': {'order': -3, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-3', 'md': {'order': -2, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-26', 'md': {'order': 5, 'blarg': 2, 'vp': True}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-14', 'md': {'order': -5, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-11', 'md': {'order': -2, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-20', 'md': {'order': -4, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-1', 'md': {'order': 1, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-22', 'md': {'order': -5, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-44', 'md': {'order': 1, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-47', 'md': {'order': -5, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-9', 'md': {'order': 1, 'blarg': 2, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-13', 'md': {'order': -4, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
S> connection made
C> status: TSDBStatus.OK
C> payload: None
C> msg {'op': 'upsert_meta', 'pk': 'ts-28', 'md': {'order': 2, 'blarg': 1, 'vp': False}}
S> connection lost
S> connection made
S> connection lost
C> status: TSDBStatus.OK
C> payload: None
UPSERTS FINISHED
---------------------
STARTING SELECTS
---------DEFAULT------------
S> connection made
S> D> NO FIELDS
S> connection lost
C> status: TSDBStatus.OK
C> payload: ['ts-16', 'ts-0', 'ts-45', 'ts-40', 'ts-10', 'ts-4', 'ts-36', 'ts-47', 'ts-38', 'ts-39', 'ts-30', 'ts-8', 'ts-34', 'ts-23', 'ts-20', 'ts-12', 'ts-44', 'ts-28', 'ts-24', 'ts-25', 'ts-9', 'ts-19', 'ts-37', 'ts-18', 'ts-2', 'ts-35', 'ts-1', 'ts-26', 'ts-14', 'ts-48', 'ts-29', 'ts-3', 'ts-15', 'ts-49', 'ts-31', 'ts-7', 'ts-11', 'ts-32', 'ts-22', 'ts-17', 'ts-42', 'ts-43', 'ts-13', 'ts-21', 'ts-5', 'ts-27', 'ts-6', 'ts-46', 'ts-41', 'ts-33']
---------ADDITIONAL------------
S> connection made
S> D> NO FIELDS
S> connection lost
C> status: TSDBStatus.OK
C> payload: ['ts-40', 'ts-26', 'ts-36', 'ts-24', 'ts-25', 'ts-19', 'ts-37', 'ts-48', 'ts-43', 'ts-46', 'ts-16', 'ts-45', 'ts-28', 'ts-39', 'ts-44', 'ts-9', 'ts-35', 'ts-1', 'ts-23', 'ts-33', 'ts-38', 'ts-7', 'ts-5', 'ts-6', 'ts-0', 'ts-8', 'ts-34', 'ts-3', 'ts-31', 'ts-11', 'ts-17', 'ts-42', 'ts-2', 'ts-49', 'ts-32', 'ts-27', 'ts-20', 'ts-18', 'ts-13', 'ts-21', 'ts-41', 'ts-10', 'ts-4', 'ts-47', 'ts-30', 'ts-12', 'ts-14', 'ts-29', 'ts-15', 'ts-22']
----------ORDER FIELD-----------
S> connection made
S> D> FIELDS ['order']
S> connection lost
C> status: TSDBStatus.OK
C> payload: ['ts-16', 'ts-0', 'ts-45', 'ts-40', 'ts-10', 'ts-4', 'ts-36', 'ts-47', 'ts-38', 'ts-39', 'ts-30', 'ts-8', 'ts-34', 'ts-23', 'ts-20', 'ts-12', 'ts-44', 'ts-28', 'ts-24', 'ts-25', 'ts-9', 'ts-19', 'ts-37', 'ts-18', 'ts-2', 'ts-35', 'ts-1', 'ts-26', 'ts-14', 'ts-48', 'ts-29', 'ts-3', 'ts-15', 'ts-49', 'ts-31', 'ts-7', 'ts-11', 'ts-32', 'ts-22', 'ts-17', 'ts-42', 'ts-43', 'ts-13', 'ts-21', 'ts-5', 'ts-27', 'ts-6', 'ts-46', 'ts-41', 'ts-33']
ts-16 OrderedDict([('order', 2)])
ts-0 OrderedDict([('order', -2)])
ts-45 OrderedDict([('order', 2)])
ts-40 OrderedDict([('order', 5)])
ts-10 OrderedDict([('order', -5)])
ts-4 OrderedDict([('order', -5)])
ts-36 OrderedDict([('order', 3)])
ts-47 OrderedDict([('order', -5)])
ts-38 OrderedDict([('order', -1)])
ts-39 OrderedDict([('order', 1)])
ts-30 OrderedDict([('order', -5)])
ts-8 OrderedDict([('order', -2)])
ts-34 OrderedDict([('order', -2)])
ts-23 OrderedDict([('order', 0)])
ts-20 OrderedDict([('order', -4)])
ts-12 OrderedDict([('order', -5)])
ts-44 OrderedDict([('order', 1)])
ts-28 OrderedDict([('order', 2)])
ts-24 OrderedDict([('order', 3)])
ts-25 OrderedDict([('order', 3)])
ts-9 OrderedDict([('order', 1)])
ts-19 OrderedDict([('order', 3)])
ts-37 OrderedDict([('order', 3)])
ts-18 OrderedDict([('order', -4)])
ts-2 OrderedDict([('order', -3)])
ts-35 OrderedDict([('order', 1)])
ts-1 OrderedDict([('order', 1)])
ts-26 OrderedDict([('order', 5)])
ts-14 OrderedDict([('order', -5)])
ts-48 OrderedDict([('order', 3)])
ts-29 OrderedDict([('order', -5)])
ts-3 OrderedDict([('order', -2)])
ts-15 OrderedDict([('order', -5)])
ts-49 OrderedDict([('order', -3)])
ts-31 OrderedDict([('order', -2)])
ts-7 OrderedDict([('order', -1)])
ts-11 OrderedDict([('order', -2)])
ts-32 OrderedDict([('order', -3)])
ts-22 OrderedDict([('order', -5)])
ts-17 OrderedDict([('order', -2)])
ts-42 OrderedDict([('order', -2)])
ts-43 OrderedDict([('order', 3)])
ts-13 OrderedDict([('order', -4)])
ts-21 OrderedDict([('order', -4)])
ts-5 OrderedDict([('order', -1)])
ts-27 OrderedDict([('order', -3)])
ts-6 OrderedDict([('order', -1)])
ts-46 OrderedDict([('order', 3)])
ts-41 OrderedDict([('order', -4)])
ts-33 OrderedDict([('order', 0)])
---------ALL FILEDS------------
S> connection made
S> D> ALL FIELDS
S> connection lost
C> status: TSDBStatus.OK
C> payload: ['ts-16', 'ts-0', 'ts-45', 'ts-40', 'ts-10', 'ts-4', 'ts-36', 'ts-47', 'ts-38', 'ts-39', 'ts-30', 'ts-8', 'ts-34', 'ts-23', 'ts-20', 'ts-12', 'ts-44', 'ts-28', 'ts-24', 'ts-25', 'ts-9', 'ts-19', 'ts-37', 'ts-18', 'ts-2', 'ts-35', 'ts-1', 'ts-26', 'ts-14', 'ts-48', 'ts-29', 'ts-3', 'ts-15', 'ts-49', 'ts-31', 'ts-7', 'ts-11', 'ts-32', 'ts-22', 'ts-17', 'ts-42', 'ts-43', 'ts-13', 'ts-21', 'ts-5', 'ts-27', 'ts-6', 'ts-46', 'ts-41', 'ts-33']
------------TS with order 1---------
S> connection made
S> D> FIELDS ['ts']
S> connection lost
C> status: TSDBStatus.OK
C> payload: ['ts-39', 'ts-44', 'ts-9', 'ts-1', 'ts-35']
------------All fields, blarg 1 ---------
S> connection made
S> D> ALL FIELDS
S> connection lost
C> status: TSDBStatus.OK
C> payload: ['ts-16', 'ts-0', 'ts-48', 'ts-6', 'ts-10', 'ts-39', 'ts-23', 'ts-20', 'ts-12', 'ts-44', 'ts-28', 'ts-19', 'ts-18', 'ts-2', 'ts-1', 'ts-14', 'ts-3', 'ts-15', 'ts-49', 'ts-42', 'ts-13', 'ts-5', 'ts-37', 'ts-27', 'ts-33']
------------order 1 blarg 2 no fields---------
S> connection made
S> D> NO FIELDS
S> connection lost
C> status: TSDBStatus.OK
C> payload: ['ts-9', 'ts-35']
OrderedDict([('ts-9', OrderedDict()), ('ts-35', OrderedDict())])
------------order >= 4  order, blarg and mean sent back, also sorted---------
S> connection made
S> D> FIELDS ['order', 'blarg', 'mean']
S> connection lost
C> status: TSDBStatus.OK
C> payload: ['ts-40', 'ts-26']
ts-40 OrderedDict([('mean', 0.9772572157208969), ('order', 5), ('blarg', 2)])
ts-26 OrderedDict([('mean', 0.9606522011373108), ('order', 5), ('blarg', 2)])
------------order 1 blarg >= 1 fields blarg and std---------
S> connection made
S> D> FIELDS ['blarg', 'std']
S> connection lost
C> status: TSDBStatus.OK
C> payload: ['ts-35', 'ts-44', 'ts-9', 'ts-1', 'ts-39']
ts-35 OrderedDict([('std', 0.38172986923525354), ('blarg', 2)])
ts-44 OrderedDict([('std', 2.114774292589706), ('blarg', 1)])
ts-9 OrderedDict([('std', 0.7957385531075051), ('blarg', 2)])
ts-1 OrderedDict([('std', 1.342715089608243), ('blarg', 1)])
ts-39 OrderedDict([('std', 0.7146238317230009), ('blarg', 1)])
------now computing vantage point stuff---------------------
VPS ['ts-31', 'ts-0', 'ts-29', 'ts-48', 'ts-26']
S> connection made
S> D> NO FIELDS
S> connection lost
C> status: TSDBStatus.OK
C> payload: ['ts-31', 'ts-29', 'ts-48', 'ts-0', 'ts-26']
ts-31 OrderedDict([('vpdist', 0.46924684861166055)])
ts-29 OrderedDict([('vpdist', 0.5706673028803376)])
ts-48 OrderedDict([('vpdist', 0.7885959374121438)])
ts-0 OrderedDict([('vpdist', 0.15519154308089217)])
ts-26 OrderedDict([('vpdist', 0.18502218147337385)])
vpwanted ts-0 1 3 0.15519154308089217
S> connection made
S> D> NO FIELDS
S> connection lost
C> status: TSDBStatus.OK
C> payload: ['ts-32', 'ts-8', 'ts-0', 'ts-20', 'ts-39', 'ts-18', 'ts-26', 'ts-22']
ts-32 OrderedDict([('towantedvp', 0.1788339871629938)])
ts-8 OrderedDict([('towantedvp', 0.12309372999233789)])
ts-0 OrderedDict([('towantedvp', 0.15519154308089217)])
ts-20 OrderedDict([('towantedvp', 0.20161319516880466)])
ts-39 OrderedDict([('towantedvp', 0.08205101172374082)])
ts-18 OrderedDict([('towantedvp', 0.3932988321503461)])
ts-26 OrderedDict([('towantedvp', 0.18502218147337385)])
ts-22 OrderedDict([('towantedvp', 0.12588947792035982)])
('ts-32', 'ts-8', 'ts-0', 'ts-20', 'ts-39', 'ts-18', 'ts-26', 'ts-22') [0.1788339871629938, 0.12309372999233789, 0.15519154308089217, 0.20161319516880466, 0.08205101172374082, 0.3932988321503461, 0.18502218147337385, 0.12588947792035982]
nearest is ts-39 distance is  0.08205101172374082
```

#define _FFTW_ESTIMATE (1U << 6)
#define FFTW_FORWARD (-1)
#define FFTW_BACKWARD (+1)